# Import built-in libraries

import boto3
import logging
import cfnresponse
import os

# Setup logger
logging.basicConfig(format='%(asctime)s - %(message)s')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Setup variables

acmclient = boto3.client('acm',region_name=os.environ['Region'])

# Define Re-usable functions

def cert_creator():
    ca = open('certs/ca.crt','r')
    serverc = open('certs/server.crt','r')
    serverk = open('certs/server.key','r')
    
    response = acmclient.import_certificate(
        Certificate=serverc.read().encode(),
        PrivateKey=serverk.read().encode(),
        CertificateChain=ca.read().encode(),
        Tags=[
            {
                'Key': 'Name',
                'Value': 'ServerCERT'
            },
            {
                'Key': 'auto-stop',
                'Value': 'no'
            },
            {
                'Key': 'auto-delete',
                'Value': 'never'
            },
        ]
    )
    return(response)

def cert_updater():
    response = acmclient.list_certificates()
    certarn = response['CertificateSummaryList'][0]['CertificateArn']
    response = acmclient.delete_certificate(
    CertificateArn=certarn
    )
    
    ca = open('certs/ca.crt','r')
    serverc = open('certs/server.crt','r')
    serverk = open('certs/server.key','r')
    
    response = acmclient.import_certificate(
        Certificate=serverc.read().encode(),
        PrivateKey=serverk.read().encode(),
        CertificateChain=ca.read().encode(),
        Tags=[
            {
                'Key': 'Name',
                'Value': 'ServerCERT'
            },
            {
                'Key': 'auto-stop',
                'Value': 'no'
            },
            {
                'Key': 'auto-delete',
                'Value': 'never'
            },
        ]
    )
    return(response)

def cert_deleter():
    response = acmclient.list_certificates()
    certarn = response['CertificateSummaryList'][0]['CertificateArn']
    response = acmclient.delete_certificate(
    CertificateArn=certarn
    )
    return(response)
    
def lambda_handler(event,context):
    try:
        response_data = {}
        logger.info(str(event))
        operation = event['RequestType']
        if operation == 'Create':
            response = cert_creator()
            logger.info(response)
            response_data['CertificateArn'] = response['CertificateArn']
        elif operation == 'Update':
            response = cert_updater()
            logger.info(response)
            response_data['CertificateArn'] = response['CertificateArn']
        else:
            response = cert_deleter()
            logger.info(response)
        cfnresponse.send(event, context, cfnresponse.SUCCESS, response_data)
    except Exception as e:
        logger.exception('Exception handled: ' + str(e) )
        logger.error('Execution failed...')
        response_data['Data'] = str(e)
        cfnresponse.send(event, context, cfnresponse.FAILED, response_data)



